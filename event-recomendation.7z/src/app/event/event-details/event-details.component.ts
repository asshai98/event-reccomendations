import { Component, OnInit, Input, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EventService } from 'src/app/services/event.service';
import { UserService } from 'src/app/services/user.service';
import { ActivatedRoute } from '@angular/router';
import { CommentService } from 'src/app/services/comment.service';

@Component({
  selector: 'app-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.css']
})
export class EventDetailsComponent implements OnInit {
  @Input() commentDetails = { event_id: null, user_id: null, content : null }

  comment = { content: null, postedBy: null }

  comments: any = [];
  commentsToShow: any = [];

  user: any = {};
  username: string;

  event: any = {};

  //displayedColumns: string[] = ['content', 'postedBy'];

  constructor(@Inject(MAT_DIALOG_DATA) public eventId: any,
              public eventService: EventService, 
              public userService: UserService, 
              public commentService: CommentService, 
              public actRoute: ActivatedRoute) { }

  ngOnInit() {
    this.getEvent();
    this.loadComments(this.eventId);
  }

  
  loadComments(event_id: number) {
    return this.commentService.getCommentsByEventtId(event_id).subscribe((data: {}) => {
      this.comments = data;

      this.comments.forEach(element => {
        this.userService.getUser(element.user_id).subscribe((data: {}) => {
          this.user = data;

          this.comment.content = element.content;
          this.comment.postedBy = this.user.username;

          this.commentsToShow.push(this.comment);
          this.comment = { content: null, postedBy: null }
        })
      });
    })
  }
  
  getEvent() {
    return this.eventService.getEvent(this.eventId).subscribe((data: {}) => {
      this.event = data;
    })
  }

  addComment() {
    this.commentDetails.event_id = this.eventId;
    this.commentDetails.user_id = UserService.currentUser.id;

    this.commentService.createComment(this.commentDetails).subscribe((data: {}) => {
      this.commentsToShow = [];
      this.loadComments(this.eventId);
    })
  }
  
}
