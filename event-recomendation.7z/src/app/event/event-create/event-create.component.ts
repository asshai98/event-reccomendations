import { Component, OnInit, Input } from '@angular/core';
import { EventService } from 'src/app/services/event.service';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-event-create',
  templateUrl: './event-create.component.html',
  styleUrls: ['./event-create.component.css']
})
export class EventCreateComponent implements OnInit {

  @Input() eventDetails = { 'name': null, 'description': null, 'location': null, 'type': null, 'starts_at': null, 'ends_at': null, 'status': 'Active', 'image': null, 'likes': 0 }

  types: any = [
    {value: 'pc-games', viewValue: 'PC Games'},
    {value: 'card-games', viewValue: 'Card Games'},
    {value: 'anime-panel', viewValue: 'Anime Panel'},
    {value: 'gaming-tournaments', viewValue: 'Gaming Tournaments'}
  ];

  constructor(public eventService: EventService, public userService: UserService, public router: Router) { }

  ngOnInit() {
    if (this.userService.is_admin == false) {
      window.confirm("Access denied!");
      this.router.navigate(['/list'])
    }
  }

  addEvent() {
    this.eventService.createEvent(this.eventDetails).subscribe((data: {}) => {
      this.router.navigate(['/list'])
    })
  }
}
