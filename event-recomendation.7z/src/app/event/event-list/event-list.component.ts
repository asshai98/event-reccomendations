import { Component, OnInit, ViewChild } from '@angular/core';
import { EventService } from 'src/app/services/event.service';
import { UserService } from 'src/app/services/user.service';
import { MatDialog } from '@angular/material/dialog';
import { EventDetailsComponent } from '../event-details/event-details.component';
import { MatTableDataSource } from '@angular/material/table';
import { ReserveService } from 'src/app/services/reserve.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.css']
})
export class EventListComponent implements OnInit {
  eventDetails = { event_id: null, user_id: null }

  events: any = [];
  eventsToShow: any = [];

  displayedColumns: string[] = ['imageUrl', 'name', 'location', 'starts_at', 'ends_at', 'status', 'reserve', 'details', 'edit', 'delete'];

  admin: boolean = this.userService.is_admin;

  dataSource: MatTableDataSource<Event>;

  resEvents: any;
  alreadyReserved = false;

  filterValues = {};
  filterSelectObj = [];

  constructor(public eventService: EventService, public userService: UserService, public reservedService: ReserveService, public dialog: MatDialog) { this.setFilters(); }

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  ngOnInit() {
    this.resEvents = ReserveService.reserved;
    this.loadEvents();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  // Get Unique values from columns to build filter
  getFilterObject(fullObj, key) {
    const uniqChk = [];

    fullObj.filter((obj) => {
      if (!uniqChk.includes(obj[key])) {
        uniqChk.push(obj[key]);
      }
      
      return obj;
    });
    
    return uniqChk;
  }

  loadEvents() {
    return this.eventService.getEvents().subscribe((data: {}) => {
      this.events = data;

      UserService.currentInterests.forEach(element => {
        this.events.forEach(event => {
          if (event.type == element.name && event.status != "Finished") {
            this.eventsToShow.push(event);
          }
        });
      });

      this.dataSource = new MatTableDataSource(this.eventsToShow);
      
      this.filterSelectObj.filter((o) => {
        o.options = this.getFilterObject(this.eventsToShow, o.columnProp);
      });
      
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;

      // Overrride default filter behaviour of Material Datatable
      this.dataSource.filterPredicate = this.createFilter();
    })
  }

  // Called on Filter change
  filterChange(filter, event) {
    //let filterValues = {}
    this.filterValues[filter.columnProp] = event.target.value.trim().toLowerCase()
    this.dataSource.filter = JSON.stringify(this.filterValues)
  }

  // Custom filter method fot Angular Material Datatable
  createFilter() {
    let filterFunction = function (data: any, filter: string): boolean {
      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;

      for (const col in searchTerms) {
        if (searchTerms[col].toString() !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[col];
        }
      }

      let nameSearch = () => {
        let found = false;

        if (isFilterSet) {
          for (const col in searchTerms) {
            searchTerms[col].trim().toLowerCase().split(' ').forEach(word => {
              if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                found = true
              }
            });
          }

          return found
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction
  }


  // Reset table filters
  resetFilters() {
    this.filterValues = {}
    this.filterSelectObj.forEach((value, key) => {
      value.modelValue = undefined;
    })
    this.dataSource.filter = "";
  }


  deleteEvent(id) {
    if (window.confirm('Are you sure, you want to delete?')) {
      this.eventService.deleteEvent(id).subscribe(data => {
        this.eventsToShow = [];
        this.setFilters();
        this.loadEvents();
      })
    }
  }

  reserve(id: number) {
    this.checkReserved(id);

    if(this.alreadyReserved == false) {
      this.eventDetails.user_id = UserService.currentUser.id;
      this.eventDetails.event_id = id;

      this.reservedService.createReservedEvent(this.eventDetails).subscribe((data: {}) => {
        window.confirm("Successfully reserved");
        this.reservedService.numberOfItems++;
      })
  }
  }

  openDialog(event_id) {
    this.dialog.open(EventDetailsComponent, {
      data: event_id
    });
  }

  checkReserved(event_id) {
    this.resEvents.forEach(element => {
      if (element.event_id == event_id) {
        window.confirm("You already reserved this event!");
        this.alreadyReserved = true;
      }
    });
  }

  setFilters() {
    this.filterSelectObj = [
      {
        name: 'Name',
        columnProp: 'name',
        options: []
      },
      {
        name: 'Location',
        columnProp: 'location',
        options: []
      },
      {
        name: 'Type',
        columnProp: 'type',
        options: []
      },
      {
        name: 'Starts at',
        columnProp: 'starts_at',
        options: []
      },
      {
        name: 'Ends at',
        columnProp: 'ends_at',
        options: []
      }
    ]
  }

}
