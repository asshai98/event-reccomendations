import { Component, OnInit } from '@angular/core';
import { EventService } from 'src/app/services/event.service';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { MatTableDataSource } from '@angular/material/table';
import { PreviousService } from 'src/app/services/previous.service';

@Component({
  selector: 'app-previous',
  templateUrl: './previous.component.html',
  styleUrls: ['./previous.component.css']
})
export class PreviousComponent implements OnInit {
  previousEvents: any = [];
  peToShow: any = [];
  static brojac = 0;

  pEvent: any = {};

  displayedColumns: string[] = [ 'id', 'name', 'status', 'likes', 'like', 'delete'];
  dataSource: MatTableDataSource<any>;

  previousEvent = { id: null, event_id: null, name: null, status: null, likes: null, count: null }
  static likedEvents = [];
  likedEvent = { likes: null }
  alreadyLiked = false;

  constructor(public previousService: PreviousService, public eventService: EventService, public router: Router) { }

  ngOnInit() {
    this.loadPreviousEvents();
  }

  loadPreviousEvents() {
    PreviousComponent.brojac = 0;

    return this.previousService.getPreviousEventsByUserId(UserService.currentUser.id).subscribe((data: {}) => {
      this.previousEvents = data;

      this.previousEvents.forEach(element => {
        this.eventService.getEvent(element.event_id).subscribe((data: {}) => {
          this.pEvent = data;

          this.previousEvent.id = element.id;
          this.previousEvent.event_id = element.event_id;
          this.previousEvent.name = this.pEvent.name;
          this.previousEvent.status = this.pEvent.status;
          this.previousEvent.likes = this.pEvent.likes;
          this.previousEvent.count = ++PreviousComponent.brojac;

          this.peToShow.push(this.previousEvent);

          this.previousEvent = { id: null, event_id: null, name: null, status: null, likes: null, count: null }
        });
      });

      this.dataSource = new MatTableDataSource(this.peToShow);
    });
  }

  like(event) {
    this.checkIfLiked(event.event_id);

    if (this.alreadyLiked == false) {
      this.likedEvent.likes = event.likes + 1;
      this.eventService.updateEventLikes(event.event_id, this.likedEvent).subscribe(data => {
        PreviousComponent.likedEvents.push(event.event_id);
        this.peToShow = [];
        this.loadPreviousEvents();
      })
    }
  }

  checkIfLiked(event_id) {
    this.alreadyLiked = false;

    PreviousComponent.likedEvents.forEach(element => {
      if(element == event_id) {
        window.confirm("You already liked this event!");
        this.alreadyLiked = true;
      }
    });
  }

}
