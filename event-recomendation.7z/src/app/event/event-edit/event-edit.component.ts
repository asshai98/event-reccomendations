import { Component, OnInit } from '@angular/core';
import { EventService } from 'src/app/services/event.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-event-edit',
  templateUrl: './event-edit.component.html',
  styleUrls: ['./event-edit.component.css']
})
export class EventEditComponent implements OnInit {
  id = this.actRoute.snapshot.params['id'];
  eventData: any = {};

  status: any = [
    {value: 'Active', viewValue: 'Active'},
    {value: 'Cancelled', viewValue: 'Cancelled'},
    {value: 'Finished', viewValue: 'Finished'}
  ];

  types: any = [
    {value: 'pc-games', viewValue: 'PC Games'},
    {value: 'card-games', viewValue: 'Card Games'},
    {value: 'anime-panel', viewValue: 'Anime Panel'},
    {value: 'gaming-tournaments', viewValue: 'Gaming Tournaments'}
  ];

  constructor(
    public eventService: EventService, 
    public actRoute: ActivatedRoute,
    public router: Router) { }

  ngOnInit() {
    this.eventService.getEvent(this.id).subscribe((data: {}) => {
      this.eventData = data;
    })
  }

  updateEvent() {
    if(window.confirm('Are you sure, you want to update?')){
      this.eventService.updateEvent(this.id, this.eventData).subscribe(data => {
        this.router.navigate(['/list'])
      })
    }
  }

}
