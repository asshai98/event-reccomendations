import { Component, OnInit } from '@angular/core';
import { ReserveService } from 'src/app/services/reserve.service';
import { EventService } from 'src/app/services/event.service';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { MatTableDataSource } from '@angular/material/table';
import { Reserved } from 'src/app/models/reserved';

@Component({
  selector: 'app-reserved',
  templateUrl: './reserved.component.html',
  styleUrls: ['./reserved.component.css']
})
export class ReservedComponent implements OnInit {
  reservedEvents: any = [];
  reToShow: any = [];

  static brojac = 0; 

  rEvent: any = {};

  reservedEvent = { id: null, event_id: null, name: null, status: 'Reserved', count: null }

  constructor(public reservedService: ReserveService, public eventService: EventService, public router: Router) { }

  ngOnInit() {
    this.loadReservedEvents();
  }

  loadReservedEvents() {
    ReservedComponent.brojac = 0;
    
    return this.reservedService.getReservedEventsByUserId(UserService.currentUser.id).subscribe((data: {}) => {
      this.reservedEvents = data;

      this.reservedEvents.forEach(element => {
          this.eventService.getEvent(element.event_id).subscribe((data: {}) => {
              if (data !== null) {
              this.rEvent = data;
              this.reservedEvent.id = element.id;
              this.reservedEvent.event_id = element.event_id;
              this.reservedEvent.name = this.rEvent.name;
              this.reservedEvent.count = ++ReservedComponent.brojac;

              this.reToShow.push(this.reservedEvent);

              this.reservedEvent = { id: null, event_id: null, name: null, status: 'Reserved', count: null }
            }
          });
      });

      ReserveService.reserved = this.reToShow;
    });
  }

  deleteItem(id) {
    if (window.confirm('Are you sure, you want to delete?')) {
      this.reservedService.deleteReservedEvent(id).subscribe(data => {
        this.reToShow = [];
        --this.reservedService.numberOfItems;
        this.loadReservedEvents();
      })
    }
  }

}
