import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './user/login/login.component';
import { ProfileComponent } from './user/profile/profile.component';
import { RegistrationComponent } from './user/registration/registration.component';
import { EventListComponent } from './event/event-list/event-list.component';
import { EventCreateComponent } from './event/event-create/event-create.component';
import { EventEditComponent } from './event/event-edit/event-edit.component';
import { EventDetailsComponent } from './event/event-details/event-details.component';
import { ReservedComponent } from './event/reserved/reserved.component';
import { PreviousComponent } from './event/previous/previous.component';

const rute: Routes = [
    {path: '', component: LoginComponent},
    {path: 'profile', component: ProfileComponent},
    {path: 'registration', component: RegistrationComponent},
    {path: 'list', component: EventListComponent},
    {path: 'create', component: EventCreateComponent},
    {path: 'edit/:id', component: EventEditComponent},
    {path: 'details', component: EventDetailsComponent},
    {path: 'reserved', component: ReservedComponent},
    {path: 'previous', component: PreviousComponent}
]

@NgModule({
    imports: [RouterModule.forRoot(rute)],
    exports: [RouterModule]
})

export class RoutingModule {}