import { Component, OnInit, Input } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { InterestService } from 'src/app/services/interest.service';
import {FormControl} from '@angular/forms';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  @Input() userDetails = { forename: null, surname: null, address: null, email: null, username: null, password: null, selectedValue: null }
  selectedValue: any = [];
  interest: any = { 'user_id': null, 'name': null } 

  interests: any = [
    {value: 'pc-games', viewValue: 'PC Games'},
    {value: 'card-games', viewValue: 'Card Games'},
    {value: 'anime-panel', viewValue: 'Anime Panel'},
    {value: 'gaming-tournaments', viewValue: 'Gaming Tournaments'}
  ];

  allUsers: any = [];
  emailExists: boolean = false;

  constructor(public userService: UserService, public interestService: InterestService, public router: Router) { }

  ngOnInit() {
    UserService.currentUser = null;
  }

  addUser(dataUser) {
    this.userService.getUsers().subscribe((data: {}) => {
      this.allUsers = data;

      this.allUsers.forEach(element => {
        if (element.email == dataUser.email) {
          this.emailExists = true;
        }
      });
      
      if (this.emailExists) {
        window.alert("The user with this email already exists!");
        this.emailExists = false;
      } else {
          this.userService.createUser(this.userDetails).subscribe((data: {}) => {
          UserService.currentUser = data;

          UserService.currentInterests = [];

          this.selectedValue.forEach(element => {
            this.interest.user_id = UserService.currentUser.id;
            this.interest.name = element;

            this.interestService.createInterest(this.interest).subscribe((data: {}) => {
              UserService.currentInterests.push(data);
              this.interest = { 'user_id': null, 'name': null }; 
            })

          });

          console.log(UserService.currentInterests)

          this.userService.is_loggedIn = true;
          this.router.navigate(['/profile']);
        });
      }
    });
  }
}
