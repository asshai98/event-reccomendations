import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { InterestService } from 'src/app/services/interest.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  userData: any = {};
  userInterests: any = [];
  toshow: any = [];

  allUsers: any = [];
  emailExists: boolean = false;

  interest: any = { 'user_id': null, 'name': null } 

  interests: any = [
    {value: 'pc-games', viewValue: 'PC Games'},
    {value: 'card-games', viewValue: 'Card Games'},
    {value: 'anime-panel', viewValue: 'Anime Panel'},
    {value: 'gaming-tournaments', viewValue: 'Gaming Tournaments'}
  ];

  constructor(public userService: UserService, public interestService:InterestService, public router: Router) { }

  ngOnInit() {
    this.userData = UserService.currentUser;
    this.userInterests = UserService.currentInterests;

    this.userInterests.forEach(element => {
      this.toshow.push(element.name);
    });
  }

  updateUser() {
    this.userService.getUsers().subscribe((data: {}) => {
      this.allUsers = data;

      this.allUsers.forEach(element => {
        if (element.email == this.userData.email) {
          this.emailExists = true;
        }
      });
      
      if (this.userData.email == UserService.currentUser.email) {
        if(window.confirm('Are you sure, you want to update?')) {

          this.userService.updateUser(this.userData.id, this.userData).subscribe(data => {

            this.userInterests.forEach(element => {
              this.interestService.deleteInterest(element.id).subscribe((data: {}) => {

              })
            });

            UserService.currentInterests = [];

            this.toshow.forEach(element => {
              this.interest.user_id = UserService.currentUser.id;
              this.interest.name = element;
  
              this.interestService.createInterest(this.interest).subscribe((data: {}) => {
                UserService.currentInterests.push(data);
                
                this.interest = { 'user_id': null, 'name': null }; 
              })
  
            });
          })
        }
      } else if (this.emailExists) {
        window.alert("The user with this email already exists!");
        this.emailExists = false;
      } else {
        if(window.confirm('Are you sure, you want to update?')) {

          this.userService.updateUser(this.userData.id, this.userData).subscribe(data => {

            this.userInterests.forEach(element => {
              this.interestService.deleteInterest(element.id).subscribe((data: {}) => {

              })
            });

            UserService.currentInterests = [];

            this.toshow.forEach(element => {
              this.interest.user_id = UserService.currentUser.id;
              this.interest.name = element;
  
              this.interestService.createInterest(this.interest).subscribe((data: {}) => {
                UserService.currentInterests.push(data);
                this.interest = { 'user_id': null, 'name': null }; 
              })
  
            });
          })
        }
      }
    });
  }
}