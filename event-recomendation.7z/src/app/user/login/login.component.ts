import { Component, OnInit, Input } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { InterestService } from 'src/app/services/interest.service';
import { ReserveService } from 'src/app/services/reserve.service';
import { EventService } from 'src/app/services/event.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @Input() userDetails = { email: null, password: null }

  reserved: any;

  rEvent: any = {}

  constructor(public userService: UserService, public interestService: InterestService, public reserveService: ReserveService, public eventService: EventService, public router: Router) { }

  ngOnInit() { }

  login() {
    this.userService.getUserByEmail(this.userDetails.email).subscribe((data: {}) => {
      UserService.currentUser = data;
      this.userService.is_loggedIn = true;

      if (UserService.currentUser.is_admin == true) {
        this.userService.is_admin = true;
      }
      
      if (this.userDetails.password == UserService.currentUser.password) {
        this.interestService.getInterestsByUserId(UserService.currentUser.id).subscribe((data: {}) => {
          UserService.currentInterests = data;

          this.reserveService.getReservedEventsByUserId(UserService.currentUser.id).subscribe((data: {}) => {
            this.reserved = data;
            ReserveService.reserved = this.reserved;

            this.reserved.forEach(element => {
              this.eventService.getEvent(element.event_id).subscribe((data: {}) => {
                if (data !== null) { 
                  ++this.reserveService.numberOfItems; 
                } 
              })
            });

            this.router.navigate(['/list']);
          });
        })
      } else {
        this.userService.is_loggedIn = false;
        window.confirm("Wrong credentials");
      }
    });
  }
}
