import { Component, OnInit } from '@angular/core';
import { UserService } from './services/user.service';
import { ReserveService } from './services/reserve.service';
import { PreviousComponent } from './event/previous/previous.component';
import { ReservedComponent } from './event/reserved/reserved.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'kwa-projekat-dva';

  constructor(public userService: UserService, public reservedService: ReserveService) { }

  ngOnInit() {
  }
  
  logout() {
    UserService.currentUser = null;
    this.userService.is_loggedIn = false;
    this.userService.is_admin = false;
    this.reservedService.numberOfItems = 0;
    ReservedComponent.brojac = 0;
    PreviousComponent.brojac = 0;
    PreviousComponent.likedEvents = [];
  }

  getCount() {
    return this.reservedService.numberOfItems;
  }
}
