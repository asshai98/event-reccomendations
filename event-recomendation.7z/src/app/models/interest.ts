export class Interest {
    id: number;
    user_id: number;
    name: string;
}