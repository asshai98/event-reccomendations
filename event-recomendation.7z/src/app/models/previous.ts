export class Previous {
    id: number;
    event_id: number;
    user_id: number;
}