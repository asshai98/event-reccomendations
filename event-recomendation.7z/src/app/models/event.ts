export class Event {
    id: number;
    name: string;
    description: string;
    location: string;
    type: string;
    starts_at: string;
    ends_at: string;
    status: string;
    image: string;
    likes: number;
}