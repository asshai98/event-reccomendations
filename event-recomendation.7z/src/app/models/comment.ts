export class Comment {
    id: number;
    event_id: number;
    user_id: number;
    content: string;
}