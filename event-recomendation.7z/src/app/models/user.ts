export class User {
    id: number;
    forename: string;
    surname: string;
    address: string;
    email: string;
    username: string;
    password: string;
    is_admin: boolean;
}