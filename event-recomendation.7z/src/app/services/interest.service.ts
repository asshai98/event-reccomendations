import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Interest } from '../models/interest';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class InterestService {

  apiURL = 'http://localhost:8080';

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  constructor(private http: HttpClient) { }

  getInterests(): Observable<Interest> {
    return this.http.get<Interest>(this.apiURL + '/interest')
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  getInterestsByUserId(user_id): Observable<Interest> {
    return this.http.get<Interest>(this.apiURL + '/interest/' + user_id)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  createInterest(interest): Observable<Interest> {
    return this.http.post<Interest>(this.apiURL + '/interest', JSON.stringify(interest), this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  deleteInterest(id){
    return this.http.delete<Interest>(this.apiURL + '/interest/' + id, this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  handleError(error) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
 }
}
