import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Reserved } from '../models/reserved';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ReserveService {
  numberOfItems: number = 0;

  static reserved: any;

  apiURL = 'http://localhost:8080';

  constructor(private http: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  getReservedEvents(): Observable<Reserved> {
    return this.http.get<Reserved>(this.apiURL + '/reserved')
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  getReservedEventsByUserId(user_id): Observable<Reserved> {
    return this.http.get<Reserved>(this.apiURL + '/reserved/' + user_id)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }
  
  createReservedEvent(reserved): Observable<Reserved> {
    return this.http.post<Reserved>(this.apiURL + '/reserved', JSON.stringify(reserved), this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  deleteReservedEvent(id){
    return this.http.delete<Reserved>(this.apiURL + '/reserved/' + id, this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  // Error handling 
  handleError(error) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
 }
}
