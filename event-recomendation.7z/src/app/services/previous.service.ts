import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Previous } from '../models/previous';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PreviousService {
  apiURL = 'http://localhost:8080';

  constructor(private http: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  getPreviousEvents(): Observable<Previous> {
    return this.http.get<Previous>(this.apiURL + '/previous')
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  getPreviousEventsByUserId(user_id): Observable<Previous> {
    return this.http.get<Previous>(this.apiURL + '/previous/' + user_id)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }
  
  createPreviousEvent(previous): Observable<Previous> {
    return this.http.post<Previous>(this.apiURL + '/previous', JSON.stringify(previous), this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  deletePreviousEvent(id){
    return this.http.delete<Previous>(this.apiURL + '/previous/' + id, this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  // Error handling 
  handleError(error) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
 }
}
