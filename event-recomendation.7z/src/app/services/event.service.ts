import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Event } from '../models/event';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EventService {

  apiURL = 'http://localhost:8080';

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  constructor(private http: HttpClient) { }

  getEvents(): Observable<Event> {
    return this.http.get<Event>(this.apiURL + '/event')
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  getEvent(id): Observable<Event> {
    return this.http.get<Event>(this.apiURL + '/event/' + id)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  createEvent(event): Observable<Event> {
    return this.http.post<Event>(this.apiURL + '/event', JSON.stringify(event), this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }
  
  updateEvent(id, event): Observable<Event> {
    return this.http.put<Event>(this.apiURL + '/event/' + id, JSON.stringify(event), this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  updateEventStatus(event_id, eventStatus): Observable<Event> {
    return this.http.put<Event>(this.apiURL + '/event/status/' + event_id, JSON.stringify(eventStatus), this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  updateEventLikes(event_id, eventLikes): Observable<Event> {
    return this.http.put<Event>(this.apiURL + '/event/likes/' + event_id, JSON.stringify(eventLikes), this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  deleteEvent(id){
    return this.http.delete<Event>(this.apiURL + '/event/' + id, this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  handleError(error) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
 }
}
